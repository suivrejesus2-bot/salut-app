import React, { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { RadioGroup, RadioGroupItem } from '../components/ui/radio-group';
import { Label } from '../components/ui/label';
import { Input } from '../components/ui/input';
import { Heart, Book, Users, Star, ChevronRight, Home, BookOpen, Trophy, Clock, Settings, Calendar, Bell, Check, Search, Copy, Bookmark, BookmarkCheck, ChevronLeft, Loader2 } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  reference: string;
}

interface Prayer {
  id: number;
  title: string;
  text: string;
  category: string;
}

interface BibleBook {
  id: string;
  name: string;
  testament: 'ancien' | 'nouveau';
  chapters: number;
  abbreviation: string;
}

// Liste des livres de la Bible
const bibleBooks: BibleBook[] = [
  // Ancien Testament
  { id: 'genese', name: 'Genèse', testament: 'ancien', chapters: 50, abbreviation: 'gen' },
  { id: 'exode', name: 'Exode', testament: 'ancien', chapters: 40, abbreviation: 'exo' },
  { id: 'levitique', name: 'Lévitique', testament: 'ancien', chapters: 27, abbreviation: 'lev' },
  { id: 'nombres', name: 'Nombres', testament: 'ancien', chapters: 36, abbreviation: 'num' },
  { id: 'deuteronome', name: 'Deutéronome', testament: 'ancien', chapters: 34, abbreviation: 'deu' },
  { id: 'josue', name: 'Josué', testament: 'ancien', chapters: 24, abbreviation: 'jos' },
  { id: 'juges', name: 'Juges', testament: 'ancien', chapters: 21, abbreviation: 'jdg' },
  { id: 'ruth', name: 'Ruth', testament: 'ancien', chapters: 4, abbreviation: 'rut' },
  { id: '1samuel', name: '1 Samuel', testament: 'ancien', chapters: 31, abbreviation: '1sa' },
  { id: '2samuel', name: '2 Samuel', testament: 'ancien', chapters: 24, abbreviation: '2sa' },
  { id: '1rois', name: '1 Rois', testament: 'ancien', chapters: 22, abbreviation: '1ki' },
  { id: '2rois', name: '2 Rois', testament: 'ancien', chapters: 25, abbreviation: '2ki' },
  { id: '1chroniques', name: '1 Chroniques', testament: 'ancien', chapters: 29, abbreviation: '1ch' },
  { id: '2chroniques', name: '2 Chroniques', testament: 'ancien', chapters: 36, abbreviation: '2ch' },
  { id: 'esdras', name: 'Esdras', testament: 'ancien', chapters: 10, abbreviation: 'ezr' },
  { id: 'nehemie', name: 'Néhémie', testament: 'ancien', chapters: 13, abbreviation: 'neh' },
  { id: 'esther', name: 'Esther', testament: 'ancien', chapters: 10, abbreviation: 'est' },
  { id: 'job', name: 'Job', testament: 'ancien', chapters: 42, abbreviation: 'job' },
  { id: 'psaumes', name: 'Psaumes', testament: 'ancien', chapters: 150, abbreviation: 'psa' },
  { id: 'proverbes', name: 'Proverbes', testament: 'ancien', chapters: 31, abbreviation: 'pro' },
  { id: 'ecclesiaste', name: 'Ecclésiaste', testament: 'ancien', chapters: 12, abbreviation: 'ecc' },
  { id: 'cantique', name: 'Cantique des Cantiques', testament: 'ancien', chapters: 8, abbreviation: 'sng' },
  { id: 'esaie', name: 'Ésaïe', testament: 'ancien', chapters: 66, abbreviation: 'isa' },
  { id: 'jeremie', name: 'Jérémie', testament: 'ancien', chapters: 52, abbreviation: 'jer' },
  { id: 'lamentations', name: 'Lamentations', testament: 'ancien', chapters: 5, abbreviation: 'lam' },
  { id: 'ezechiel', name: 'Ézéchiel', testament: 'ancien', chapters: 48, abbreviation: 'eze' },
  { id: 'daniel', name: 'Daniel', testament: 'ancien', chapters: 12, abbreviation: 'dan' },
  { id: 'osee', name: 'Osée', testament: 'ancien', chapters: 14, abbreviation: 'hos' },
  { id: 'joel', name: 'Joël', testament: 'ancien', chapters: 3, abbreviation: 'jol' },
  { id: 'amos', name: 'Amos', testament: 'ancien', chapters: 9, abbreviation: 'amo' },
  { id: 'abdias', name: 'Abdias', testament: 'ancien', chapters: 1, abbreviation: 'oba' },
  { id: 'jonas', name: 'Jonas', testament: 'ancien', chapters: 4, abbreviation: 'jon' },
  { id: 'michee', name: 'Michée', testament: 'ancien', chapters: 7, abbreviation: 'mic' },
  { id: 'nahum', name: 'Nahum', testament: 'ancien', chapters: 3, abbreviation: 'nam' },
  { id: 'habakuk', name: 'Habakuk', testament: 'ancien', chapters: 3, abbreviation: 'hab' },
  { id: 'sophonie', name: 'Sophonie', testament: 'ancien', chapters: 3, abbreviation: 'zep' },
  { id: 'aggee', name: 'Aggée', testament: 'ancien', chapters: 2, abbreviation: 'hag' },
  { id: 'zacharie', name: 'Zacharie', testament: 'ancien', chapters: 14, abbreviation: 'zec' },
  { id: 'malachie', name: 'Malachie', testament: 'ancien', chapters: 4, abbreviation: 'mal' },
  
  // Nouveau Testament
  { id: 'matthieu', name: 'Matthieu', testament: 'nouveau', chapters: 28, abbreviation: 'mat' },
  { id: 'marc', name: 'Marc', testament: 'nouveau', chapters: 16, abbreviation: 'mrk' },
  { id: 'luc', name: 'Luc', testament: 'nouveau', chapters: 24, abbreviation: 'luk' },
  { id: 'jean', name: 'Jean', testament: 'nouveau', chapters: 21, abbreviation: 'jhn' },
  { id: 'actes', name: 'Actes', testament: 'nouveau', chapters: 28, abbreviation: 'act' },
  { id: 'romains', name: 'Romains', testament: 'nouveau', chapters: 16, abbreviation: 'rom' },
  { id: '1corinthiens', name: '1 Corinthiens', testament: 'nouveau', chapters: 16, abbreviation: '1co' },
  { id: '2corinthiens', name: '2 Corinthiens', testament: 'nouveau', chapters: 13, abbreviation: '2co' },
  { id: 'galates', name: 'Galates', testament: 'nouveau', chapters: 6, abbreviation: 'gal' },
  { id: 'ephesiens', name: 'Éphésiens', testament: 'nouveau', chapters: 6, abbreviation: 'eph' },
  { id: 'philippiens', name: 'Philippiens', testament: 'nouveau', chapters: 4, abbreviation: 'php' },
  { id: 'colossiens', name: 'Colossiens', testament: 'nouveau', chapters: 4, abbreviation: 'col' },
  { id: '1thesaloniciens', name: '1 Thessaloniciens', testament: 'nouveau', chapters: 5, abbreviation: '1th' },
  { id: '2thesaloniciens', name: '2 Thessaloniciens', testament: 'nouveau', chapters: 3, abbreviation: '2th' },
  { id: '1timothée', name: '1 Timothée', testament: 'nouveau', chapters: 6, abbreviation: '1ti' },
  { id: '2timothée', name: '2 Timothée', testament: 'nouveau', chapters: 4, abbreviation: '2ti' },
  { id: 'tite', name: 'Tite', testament: 'nouveau', chapters: 3, abbreviation: 'tit' },
  { id: 'philemon', name: 'Philémon', testament: 'nouveau', chapters: 1, abbreviation: 'phm' },
  { id: 'hebreux', name: 'Hébreux', testament: 'nouveau', chapters: 13, abbreviation: 'heb' },
  { id: 'jacques', name: 'Jacques', testament: 'nouveau', chapters: 5, abbreviation: 'jas' },
  { id: '1pierre', name: '1 Pierre', testament: 'nouveau', chapters: 5, abbreviation: '1pe' },
  { id: '2pierre', name: '2 Pierre', testament: 'nouveau', chapters: 3, abbreviation: '2pe' },
  { id: '1jean', name: '1 Jean', testament: 'nouveau', chapters: 5, abbreviation: '1jn' },
  { id: '2jean', name: '2 Jean', testament: 'nouveau', chapters: 1, abbreviation: '2jn' },
  { id: '3jean', name: '3 Jean', testament: 'nouveau', chapters: 1, abbreviation: '3jn' },
  { id: 'jude', name: 'Jude', testament: 'nouveau', chapters: 1, abbreviation: 'jud' },
  { id: 'apocalypse', name: 'Apocalypse', testament: 'nouveau', chapters: 22, abbreviation: 'rev' }
];

const bibleQuestions: Question[] = [
  {
    id: 1,
    question: "Qui a construit l'arche?",
    options: ["Abraham", "Moïse", "Noé", "David"],
    correctAnswer: 2,
    reference: "Genèse 6:13-22"
  },
  {
    id: 2,
    question: "Combien de disciples Jésus avait-il?",
    options: ["10", "11", "12", "13"],
    correctAnswer: 2,
    reference: "Matthieu 10:1-4"
  },
  {
    id: 3,
    question: "Quel livre de la Bible commence par 'Au commencement'?",
    options: ["Exode", "Genèse", "Psaumes", "Jean"],
    correctAnswer: 1,
    reference: "Genèse 1:1"
  },
  {
    id: 4,
    question: "Qui a été jeté dans la fosse aux lions?",
    options: ["David", "Daniel", "Joseph", "Samuel"],
    correctAnswer: 1,
    reference: "Daniel 6:16-23"
  },
  {
    id: 5,
    question: "Quel est le premier commandement?",
    options: ["Tu ne tueras point", "Tu ne voleras point", "Tu aimeras Dieu", "Tu honoreras tes parents"],
    correctAnswer: 2,
    reference: "Exode 20:3"
  }
];

const prayers: Prayer[] = [
  {
    id: 1,
    title: "Prière du matin",
    text: "Seigneur, je te remercie pour cette nouvelle journée. Que ta lumière guide mes pas et que ta sagesse éclaire mes décisions. Bénis ma famille et mes amis. Au nom de Jésus, amen.",
    category: "Matin"
  },
  {
    id: 2,
    title: "Prière pour la paix",
    text: "Dieu de paix, calme mon cœur agité. Remplis-moi de ta sérénité et aide-moi à répandre l'amour autour de moi. Que ta présence apaise toute anxiété. Amen.",
    category: "Paix"
  },
  {
    id: 3,
    title: "Prière de gratitude",
    text: "Père céleste, merci pour tes innombrables bénédictions. Ouvre mes yeux pour voir ta générosité dans chaque aspect de ma vie. Que mon cœur déborde de reconnaissance. Amen.",
    category: "Gratitude"
  },
  {
    id: 4,
    title: "Prière pour la guérison",
    text: "Seigneur guérisseur, je te confie mes maladies et celles de mes proches. Étends ta main puissante et restaure la santé selon ta volonté parfaite. Amen.",
    category: "Guérison"
  }
];

const dailyVerses = [
  { text: "Car Dieu a tant aimé le monde qu'il a donné son Fils unique...", reference: "Jean 3:16" },
  { text: "Je peux tout par celui qui me fortifie.", reference: "Philippiens 4:13" },
  { text: "Le Seigneur est mon berger, je ne manque de rien.", reference: "Psaumes 23:1" },
  { text: "Ne crains rien, car je suis avec toi.", reference: "Ésaïe 41:10" },
  { text: "La joie du Seigneur est votre force.", reference: "Néhémie 8:10" }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'quiz' | 'prayers' | 'verses' | 'bible'>('home');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [selectedPrayerCategory, setSelectedPrayerCategory] = useState<string>('Toutes');
  const [dailyVerse, setDailyVerse] = useState(dailyVerses[0]);

  // États pour l'écran Bible
  const [selectedTestament, setSelectedTestament] = useState<'ancien' | 'nouveau' | 'tous'>('tous');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const today = new Date();
    setDailyVerse(dailyVerses[today.getDate() % dailyVerses.length]);
  }, []);

  // Filtrer les livres selon le testament et la recherche
  const filteredBooks = bibleBooks.filter(book => {
    const matchesTestament = selectedTestament === 'tous' || book.testament === selectedTestament;
    const matchesSearch = book.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTestament && matchesSearch;
  });

  const handleAnswerSubmit = () => {
    if (selectedAnswer !== null) {
      if (selectedAnswer === bibleQuestions[currentQuestion].correctAnswer) {
        setScore(score + 1);
      }
      setShowResult(true);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestion < bibleQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setQuizCompleted(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setScore(0);
    setShowResult(false);
    setQuizCompleted(false);
  };

  const filteredPrayers = selectedPrayerCategory === 'Toutes' 
    ? prayers 
    : prayers.filter(p => p.category === selectedPrayerCategory);

  const prayerCategories = ['Toutes', ...Array.from(new Set(prayers.map(p => p.category)))];

  return (
    <div className="min-h-screen bg-blue-50">
      <header className="bg-white shadow-sm border-b border-blue-100">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-blue-900">La Voie du Salut</h1>
            </div>
            <nav className="hidden md:flex space-x-6">
              <button
                onClick={() => setActiveTab('home')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  activeTab === 'home' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-blue-600'
                }`}
              >
                <Home className="w-4 h-4" />
                <span>Accueil</span>
              </button>
              <button
                onClick={() => setActiveTab('bible')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  activeTab === 'bible' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-blue-600'
                }`}
              >
                <Book className="w-4 h-4" />
                <span>Bible</span>
              </button>
              <button
                onClick={() => setActiveTab('quiz')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  activeTab === 'quiz' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-blue-600'
                }`}
              >
                <Trophy className="w-4 h-4" />
                <span>Quiz</span>
              </button>
              <button
                onClick={() => setActiveTab('prayers')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  activeTab === 'prayers' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-blue-600'
                }`}
              >
                <Heart className="w-4 h-4" />
                <span>Prières</span>
              </button>
              <button
                onClick={() => setActiveTab('verses')}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors ${
                  activeTab === 'verses' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-blue-600'
                }`}
              >
                <Star className="w-4 h-4" />
                <span>Versets</span>
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {activeTab === 'home' && (
          <div className="space-y-8">
            <div className="text-center py-12 bg-blue-600 rounded-2xl text-white">
              <h2 className="text-4xl font-bold mb-4">Bienvenue dans La Voie du Salut</h2>
              <p className="text-xl mb-8">Nourrissez votre âme chaque jour avec la Parole de Dieu</p>
              <div className="flex justify-center space-x-4">
                <Button onClick={() => setActiveTab('bible')} className="bg-white text-blue-600 hover:bg-blue-50">
                  <Book className="w-5 h-5 mr-2" />
                  Explorer la Bible
                </Button>
                <Button onClick={() => setActiveTab('quiz')} variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                  <Trophy className="w-5 h-5 mr-2" />
                  Faire le Quiz
                </Button>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setActiveTab('bible')}>
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <Book className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle>📖 Bible</CardTitle>
                  <CardDescription>Explorez les Saintes Écritures</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">Accédez à tous les 66 livres de la Bible</p>
                  <Button className="w-full">
                    Explorer maintenant
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setActiveTab('quiz')}>
                <CardHeader>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                    <Trophy className="w-6 h-6 text-green-600" />
                  </div>
                  <CardTitle>🏆 Quiz Biblique</CardTitle>
                  <CardDescription>Testez vos connaissances</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">Défiez-vous avec des questions bibliques</p>
                  <Button className="w-full" variant="outline">
                    Commencer le quiz
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setActiveTab('prayers')}>
                <CardHeader>
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4">
                    <Heart className="w-6 h-6 text-yellow-600" />
                  </div>
                  <CardTitle>🙏 Prières</CardTitle>
                  <CardDescription>Communiquez avec Dieu</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">Prières pour différentes occasions</p>
                  <Button className="w-full" variant="outline">
                    Prier maintenant
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-yellow-50 border-yellow-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="w-5 h-5 text-yellow-600 mr-2" />
                  Verset du Jour
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 italic mb-2">"{dailyVerse.text}"</p>
                <p className="text-sm text-gray-500">— {dailyVerse.reference}</p>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'bible' && (
          <div className="max-w-4xl mx-auto">
            <div className="mb-6">
              <h2 className="text-3xl font-bold text-blue-900 mb-2">📖 La Sainte Bible</h2>
              <p className="text-gray-600">Explorez les 66 livres de la Bible</p>
            </div>

            {/* Filtres et recherche */}
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row gap-4">
                  {/* Recherche */}
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Rechercher un livre..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  
                  {/* Filtres par testament */}
                  <div className="flex gap-2">
                    <Button
                      variant={selectedTestament === 'tous' ? 'default' : 'outline'}
                      onClick={() => setSelectedTestament('tous')}
                    >
                      Tous (66)
                    </Button>
                    <Button
                      variant={selectedTestament === 'ancien' ? 'default' : 'outline'}
                      onClick={() => setSelectedTestament('ancien')}
                    >
                      Ancien Testament (39)
                    </Button>
                    <Button
                      variant={selectedTestament === 'nouveau' ? 'default' : 'outline'}
                      onClick={() => setSelectedTestament('nouveau')}
                    >
                      Nouveau Testament (27)
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Liste des livres */}
            <div className="space-y-6">
              {/* Ancien Testament */}
              {(selectedTestament === 'tous' || selectedTestament === 'ancien') && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-xl text-blue-800">Ancien Testament</CardTitle>
                    <CardDescription>La Loi, l'Histoire, la Sagesse et les Prophètes</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {filteredBooks
                        .filter(book => book.testament === 'ancien')
                        .map((book) => (
                          <div
                            key={book.id}
                            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-blue-50 transition-colors cursor-pointer group"
                          >
                            <div>
                              <h4 className="font-medium text-gray-800 group-hover:text-blue-700">
                                {book.name}
                              </h4>
                              <p className="text-sm text-gray-500">
                                {book.chapters} chapitres
                              </p>
                            </div>
                            <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-blue-600" />
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Nouveau Testament */}
              {(selectedTestament === 'tous' || selectedTestament === 'nouveau') && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-xl text-green-800">Nouveau Testament</CardTitle>
                    <CardDescription>Les Évangiles, les Actes, les Épîtres et l'Apocalypse</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {filteredBooks
                        .filter(book => book.testament === 'nouveau')
                        .map((book) => (
                          <div
                            key={book.id}
                            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-green-50 transition-colors cursor-pointer group"
                          >
                            <div>
                              <h4 className="font-medium text-gray-800 group-hover:text-green-700">
                                {book.name}
                              </h4>
                              <p className="text-sm text-gray-500">
                                {book.chapters} chapitres
                              </p>
                            </div>
                            <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-green-600" />
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Statistiques */}
            <Card className="mt-6">
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-blue-600">66</div>
                    <div className="text-sm text-gray-600">Livres au total</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-600">39</div>
                    <div className="text-sm text-gray-600">Ancien Testament</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-green-600">27</div>
                    <div className="text-sm text-gray-600">Nouveau Testament</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-purple-600">1,189</div>
                    <div className="text-sm text-gray-600">Chapitres au total</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'quiz' && (
          <div className="max-w-2xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">🏆 Quiz Biblique</CardTitle>
                <CardDescription>Testez vos connaissances des Saintes Écritures</CardDescription>
              </CardHeader>
              <CardContent>
                {!quizCompleted ? (
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-500">
                        Question {currentQuestion + 1} sur {bibleQuestions.length}
                      </span>
                      <span className="text-sm font-medium text-blue-600">
                        Score: {score}/{currentQuestion + (showResult ? 1 : 0)}
                      </span>
                    </div>
                    
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${((currentQuestion + 1) / bibleQuestions.length) * 100}%` }}
                      />
                    </div>

                    <div>
                      <h3 className="text-lg font-semibold mb-4">
                        {bibleQuestions[currentQuestion].question}
                      </h3>
                      
                      <RadioGroup value={selectedAnswer?.toString()} onValueChange={(value) => setSelectedAnswer(parseInt(value))}>
                        {bibleQuestions[currentQuestion].options.map((option, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                            <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                              {option}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    </div>

                    {showResult && (
                      <div className={`p-4 rounded-lg ${selectedAnswer === bibleQuestions[currentQuestion].correctAnswer ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                        <p className={`font-medium ${selectedAnswer === bibleQuestions[currentQuestion].correctAnswer ? 'text-green-800' : 'text-red-800'}`}>
                          {selectedAnswer === bibleQuestions[currentQuestion].correctAnswer ? '✓ Correct!' : '✗ Incorrect'}
                        </p>
                        <p className="text-sm text-gray-600 mt-1">
                          Référence: {bibleQuestions[currentQuestion].reference}
                        </p>
                      </div>
                    )}

                    <div className="flex justify-between">
                      {!showResult ? (
                        <Button 
                          onClick={handleAnswerSubmit} 
                          disabled={selectedAnswer === null}
                          className="w-full"
                        >
                          Soumettre la réponse
                        </Button>
                      ) : (
                        <Button onClick={handleNextQuestion} className="w-full">
                          {currentQuestion < bibleQuestions.length - 1 ? 'Question suivante' : 'Voir les résultats'}
                        </Button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-center space-y-6">
                    <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                      <Trophy className="w-10 h-10 text-yellow-600" />
                    </div>
                    <h3 className="text-2xl font-bold">Quiz Terminé!</h3>
                    <p className="text-lg">
                      Votre score: <span className="font-bold text-blue-600">{score}/{bibleQuestions.length}</span>
                    </p>
                    <p className="text-gray-600">
                      {score === bibleQuestions.length ? 'Parfait! Vous connaissez bien la Bible!' :
                       score >= bibleQuestions.length * 0.7 ? 'Excellent travail!' :
                       score >= bibleQuestions.length * 0.5 ? 'Bon effort!' : 'Continuez à étudier la Parole!'}
                    </p>
                    <Button onClick={resetQuiz} className="w-full">
                      Refaire le quiz
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'prayers' && (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-3xl font-bold text-blue-900 mb-2">🙏 Prières</h2>
              <p className="text-gray-600">Des prières pour différents moments de la vie</p>
            </div>

            <div className="flex flex-wrap gap-2 mb-6">
              {prayerCategories.map((category) => (
                <Button
                  key={category}
                  variant={selectedPrayerCategory === category ? 'default' : 'outline'}
                  onClick={() => setSelectedPrayerCategory(category)}
                  size="sm"
                >
                  {category}
                </Button>
              ))}
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {filteredPrayers.map((prayer) => (
                <Card key={prayer.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Heart className="w-5 h-5 text-red-500 mr-2" />
                      {prayer.title}
                    </CardTitle>
                    <CardDescription>{prayer.category}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 italic">"{prayer.text}"</p>
                    <Button className="mt-4 w-full" variant="outline">
                      <Heart className="w-4 h-4 mr-2" />
                      Prier maintenant
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'verses' && (
          <div className="space-y-6">
            <div className="mb-6">
              <h2 className="text-3xl font-bold text-blue-900 mb-2">⭐ Versets Inspirants</h2>
              <p className="text-gray-600">Des versets bibliques pour nourrir votre foi</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {dailyVerses.map((verse, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Star className="w-5 h-5 text-yellow-500 mr-2" />
                      Verset {index + 1}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 italic mb-3">"{verse.text}"</p>
                    <p className="text-sm text-gray-500 font-medium">— {verse.reference}</p>
                    <Button className="mt-4 w-full" variant="outline" size="sm">
                      <Copy className="w-4 h-4 mr-2" />
                      Copier
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}